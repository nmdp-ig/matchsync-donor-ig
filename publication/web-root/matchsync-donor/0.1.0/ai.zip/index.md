# Home - NMDP Donor Patient Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/donor-patient/ImplementationGuide/nmdp.fhir.donor-patient | *Version*:0.1.0 |
| Draft as of 2026-09-03 | *Computable Name*:NMDPDonorPatient |

# NMDP Donor Patient Implementation Guide

This Implementation Guide defines the FHIR profiles for representing hematopoietic cell donors in the NMDP (National Marrow Donor Program / Be The Match) registry.

## Scope

The Donor Patient IG covers:

* **Donor demographics** — name, date of birth, gender, race, ethnicity
* **Donor identifiers** — NMDP Donor ID, GRID (Global Registration Identifier for Donors)
* **Donor status** — active, inactive, deferred, unavailable

## Profiles

| | | |
| :--- | :--- | :--- |
| [NMDPDonorPatient](StructureDefinition-nmdp-donor-patient.md) | Patient | A hematopoietic cell donor registered in the NMDP registry |

## Extensions

| | | |
| :--- | :--- | :--- |
| [DonorStatus](StructureDefinition-donor-status.md) | Patient | The registration status of a donor |

## Dependencies

This IG depends on:

* [FHIR R4 (4.0.1)](http://hl7.org/fhir/R4/)
* [US Core 6.1.0](http://hl7.org/fhir/us/core/STU6.1/)

