# nmdp.fhir.donor-patient#0.1.0: NMDP Donor Patient Implementation Guide

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Order Workflow](order-workflow.md)
* [Capability Statement](capability-statement.md)
* [Identifiers](identifiers.md)
* [Artifacts Summary](artifacts.md)
* [Conventions](conventions.md)
* [Security and Privacy](security-and-privacy.md)
* [Related Specifications](related-specifications.md)

## Resources

### CodeSystems

* [NMDP Center Type](CodeSystem-nmdp-center-type.md)
* [NMDP Donor Status](CodeSystem-nmdp-donor-status.md)
* [NMDP HLA Gene Name Code System](CodeSystem-nmdp-hla-gene-name.md)
* [NMDP Order Type Code System](CodeSystem-nmdp-order-type.md)
* [NMDP Specimen Type Code System](CodeSystem-nmdp-specimen-type.md)

### ValueSets

* [NMDP Center Type ValueSet](ValueSet-nmdp-center-type-vs.md)
* [NMDP Donor Status ValueSet](ValueSet-nmdp-donor-status-vs.md)
* [GL String Code Value Set](ValueSet-nmdp-glstring-vs.md)
* [NMDP HLA Gene Name Value Set](ValueSet-nmdp-hla-gene-name-vs.md)
* [NMDP Order Type Value Set](ValueSet-nmdp-order-type-vs.md)
* [NMDP Specimen Type Value Set](ValueSet-nmdp-specimen-type-vs.md)

### Resource Profiles

* [MatchSync Donor Patient](StructureDefinition-matchsync-donor-patient.md)
* [NMDP Donor Order](StructureDefinition-nmdp-donor-order.md)
* [NMDP Donor Patient](StructureDefinition-nmdp-donor-patient.md)
* [NMDP Donor Specimen](StructureDefinition-nmdp-donor-specimen.md)
* [NMDP HLA Genotype Observation](StructureDefinition-nmdp-hla-genotype.md)
* [NMDP IDM Order](StructureDefinition-nmdp-idm-order.md)
* [NMDP Organization](StructureDefinition-nmdp-organization.md)

### Extensions

* [Donor Status](StructureDefinition-donor-status.md)

### CapabilityStatements

* [NMDP Donor API Capability Statement](CapabilityStatement-NMDPDonorAPICapabilityStatement.md)

### ImplementationGuides

* [NMDP Donor Patient Implementation Guide](index.md)

### Examples

* [ExampleHLAGenotypeA (Observation)](Observation-ExampleHLAGenotypeA.md)
* [ExampleHLAGenotypeB (Observation)](Observation-ExampleHLAGenotypeB.md)
* [ExampleHLAGenotypeC (Observation)](Observation-ExampleHLAGenotypeC.md)
* [ExampleHLAGenotypeDRB1 (Observation)](Observation-ExampleHLAGenotypeDRB1.md)
* [Minneapolis Blood Center (Organization)](Organization-ExampleNMDPDonorCenter.md)
* [ExampleDeceasedDonor (Patient)](Patient-ExampleDeceasedDonor.md)
* [ExampleDeferredDonor (Patient)](Patient-ExampleDeferredDonor.md)
* [ExampleDonorNoGrid (Patient)](Patient-ExampleDonorNoGrid.md)
* [ExampleMatchSyncDonorPatient (Patient)](Patient-ExampleMatchSyncDonorPatient.md)
* [ExampleNMDPDonor (Patient)](Patient-ExampleNMDPDonor.md)
* [ExampleDonorOrder (ServiceRequest)](ServiceRequest-ExampleDonorOrder.md)
* [ExampleIDMOrder (ServiceRequest)](ServiceRequest-ExampleIDMOrder.md)
* [ExampleDonorSpecimen (Specimen)](Specimen-ExampleDonorSpecimen.md)
